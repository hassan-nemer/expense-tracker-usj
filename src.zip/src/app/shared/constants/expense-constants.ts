export const defaultExpenseCategories: string[] = [
  'Salaries',
  'Transportation',
  'food',
  'vehicles',
  'Unassigned',
 
];
export const defaultExpenseTypes: string[] = ['Gv-Funding', 'Donations', 'Army sales'];
