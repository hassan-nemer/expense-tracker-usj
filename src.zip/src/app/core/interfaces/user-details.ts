export interface UserDetails {
  firstName: string;
  lastName: string;
}
